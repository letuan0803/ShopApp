export interface ProductImage {
    id: number;
    image_url: string;
  }