export interface LoginResponse {
  message: string;
  token: string;
}
